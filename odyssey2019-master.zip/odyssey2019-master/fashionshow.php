<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Design System for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <title>Odyssey 2019</title>
  <!-- Favicon -->
  <link href="img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="vendor/nucleo/css/nucleo.css" rel="stylesheet">
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- Argon CSS -->
  <link type="text/css" href="css/argon.css?v=1.0.1" rel="stylesheet">
  <!-- Docs CSS -->
  <link type="text/css" href="css/docs.min.css" rel="stylesheet">
</head>

<body>
  <!-- <header class="header-global">
    <nav id="navbar-main" class="navbar navbar-main navbar-expand-lg navbar-transparent navbar-light headroom">
      <div class="container">
        <a class="navbar-brand mr-lg-5" href="../index.html">
          <img src="img\blueLogo.png" style="width:50%;height:300%;"> 
        </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar_global" aria-controls="navbar_global" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbar_global">
          <div class="navbar-collapse-header">
            <div class="row">
              <div class="col-6 collapse-brand">
                <a href="../index.html">
                  <img src="img/brand/blue.png">
                </a>
              </div>
              <div class="col-6 collapse-close">
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbar_global" aria-controls="navbar_global" aria-expanded="false" aria-label="Toggle navigation">
                  <span></span>
                  <span></span>
                </button>
              </div>
            </div>
          </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;          <ul class="navbar-nav navbar-nav-hover align-items-lg-center">
            <li class="nav-item dropdown">
              <a href="#" class="nav-link" data-toggle="dropdown" href="#" role="button">
                <i class="ni ni-ui-04 d-lg-none"></i>
                <span class="nav-link-inner--text">Events</span>
              </a>
              <div class="dropdown-menu dropdown-menu-xl">
                <div class="dropdown-menu-inner">
                  <a href="https://demos.creative-tim.com/argon-design-system/docs/getting-started/overview.html" class="media d-flex align-items-center">
                    <div class="icon icon-shape bg-gradient-primary rounded-circle text-white">
                      <i class="ni ni-spaceship"></i>
                    </div>
                    <div class="media-body ml-3">
                      <h6 class="heading text-primary mb-md-1">Getting started</h6>
                      <p class="description d-none d-md-inline-block mb-0">Learn how to use Argon compiling Scss, change brand colors and more.</p>
                    </div>
                  </a>
                  <a href="https://demos.creative-tim.com/argon-design-system/docs/foundation/colors.html" class="media d-flex align-items-center">
                    <div class="icon icon-shape bg-gradient-success rounded-circle text-white">
                      <i class="ni ni-palette"></i>
                    </div>
                    <div class="media-body ml-3">
                      <h6 class="heading text-primary mb-md-1">Foundation</h6>
                      <p class="description d-none d-md-inline-block mb-0">Learn more about colors, typography, icons and the grid system we used for Argon.</p>
                    </div>
                  </a>
                  <a href="https://demos.creative-tim.com/argon-design-system/docs/components/alerts.html" class="media d-flex align-items-center">
                    <div class="icon icon-shape bg-gradient-warning rounded-circle text-white">
                      <i class="ni ni-ui-04"></i>
                    </div>
                    <div class="media-body ml-3">
                      <h5 class="heading text-warning mb-md-1">Components</h5>
                      <p class="description d-none d-md-inline-block mb-0">Browse our 50 beautiful handcrafted components offered in the Free version.</p>
                    </div>
                  </a>
                </div>
              </div>
            </li>
            <li class="nav-item dropdown">
              <a href="#" class="nav-link" data-toggle="dropdown" href="#" role="button">
                <i class="ni ni-collection d-lg-none"></i>
                <span class="nav-link-inner--text">About us </span>
              </a>
              <div class="dropdown-menu">
                <a href="examples/landing.html" class="dropdown-item">Landing</a>
                <a href="examples/profile.html" class="dropdown-item">Profile</a>
                <a href="examples/login.html" class="dropdown-item">Login</a>
                <a href="examples/register.html" class="dropdown-item">Register</a>
              </div>
            </li>
          </ul>
          <ul class="navbar-nav align-items-lg-center ml-lg-auto">
            <!-- <li class="nav-item">
              <a class="nav-link nav-link-icon" href="https://www.facebook.com/creativetim" target="_blank" data-toggle="tooltip" title="Like us on Facebook">
                <i class="fa fa-facebook-square"></i>
                <span class="nav-link-inner--text d-lg-none">Facebook</span>
              </a>
            </li> -->
            <!--
            <li class="nav-item">
              <a class="nav-link nav-link-icon" href="https://www.instagram.com/creativetimofficial" target="_blank" data-toggle="tooltip" title="Follow us on Instagram">
                <i class="fa fa-instagram"></i>
                <span class="nav-link-inner--text d-lg-none">Instagram</span>
              </a>
            </li>-->
            <!--
            <li class="nav-item">
              <a class="nav-link nav-link-icon" href="https://twitter.com/creativetim" target="_blank" data-toggle="tooltip" title="Follow us on Twitter">
                <i class="fa fa-twitter-square"></i>
                <span class="nav-link-inner--text d-lg-none">Twitter</span>
              </a>
            </li>
            <!--
            <li class="nav-item">
              <a class="nav-link nav-link-icon" href="https://github.com/creativetimofficial/argon-design-system" target="_blank" data-toggle="tooltip" title="Star us on Github">
                <i class="fa fa-github"></i>
                <span class="nav-link-inner--text d-lg-none">Github</span>
              </a>
            </li>
            <li class="nav-item d-none d-lg-block ml-lg-4">
              <a href="https://www.creative-tim.com/product/argon-design-system" target="_blank" class="btn btn-outline-success">
                <!-- <span class="btn-inner--icon">
                  <i class="fa fa-cloud-download mr-2"></i>
                </span> 
                <span class="nav-link-inner--text">Login</span>
              </a>
            </li>
            <li class="nav-item d-none d-lg-block ml-lg-4">
              <a href="https://www.creative-tim.com/product/argon-design-system" target="_blank" class="btn btn-success">
                <!-- <span class="btn-inner--icon"> 
                  <!-- <i class="fa fa-cloud-download mr-2"></i>
                </span> 
                <span class="nav-link-inner--text">register</span>
              </a>
            </li>
          
          </ul>
        </div>
      </div>
    </nav>
  </header> -->
  <?php include 'nav.php';?>
  <main>
    <div class="position-relative">
      <!-- shape Hero -->
      <section style="background-image:url('img/cse0.png');background-size:contain; background-repeat: no-repeat;background-position: 50% 80px ;background-color:#3a4546;">
        <div class="shape shape-style-1 shape-default">
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          <span></span>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>

  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
        </div>
        <!-- <div class="container py-lg-md d-flex">
          <div class="col px-0">
            <div class="row">
              <div class="col-lg-6">
                <h1 class="display-3  text-white">A beautiful Design System
                  <span>completed with examples</span>
                </h1>
                <p class="lead  text-white">The design system comes with four pre-built pages to help you get started faster. You can change the text and images and you're good to go.</p>
                <div class="btn-wrapper">
                  <a href="https://demos.creative-tim.com/argon-design-system/docs/components/alerts.html" class="btn btn-info btn-icon mb-3 mb-sm-0">
                    <span class="btn-inner--icon"><i class="fa fa-code"></i></span>
                    <span class="btn-inner--text">Components</span>
                  </a>
                  <a href="https://www.creative-tim.com/product/argon-design-system" class="btn btn-white btn-icon mb-3 mb-sm-0">
                    <span class="btn-inner--icon"><i class="ni ni-cloud-download-95"></i></span>
                    <span class="btn-inner--text">Download HTML</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        SVG separator -->
        <!-- <div class="separator separator-bottom separator-skew">
          <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg">
            <polygon class="fill-white" points="2560 0 2560 100 0 100"></polygon>
          </svg>
        </div> -->
      </section>
      <!-- 1st Hero Variation -->
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
  
    <br>
    <section class="section section-lg pt-lg-0 mt--200">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-12">
            <div class="row row-grid">
              <div class="col-lg-12">
                <div class="card card-lift--hover shadow border-0">
                  <div class="card-body py-5">
                    <!--<div class="icon icon-shape icon-shape-primary rounded-circle mb-4"> -->
                      <!-- <i class="ni ni-check-bold"></i> 
                    </div> -->
                    <h6 class="text-primary text-uppercase"> Fashion Show</h6><br>
                    <b><span class="font-weight-900">Event code</b> :</span>
                       <br>
                     <b><span class="font-weight-900">Event name :</span>&nbsp;&nbsp;<span class="font-weight-600">Fashion Fiesta</span></b>
                    <br>
                    <b><span class="font-weight-900">Theme :</span>&nbsp;<span class="font-weight-600"> Bohemian Fashion </span></b>
                    <br>
                    <br>
                  <b><span class="font-weight-900">Staff Coordinator 1:</span>&nbsp;&nbsp; <span class="font-weight-600"> Prof. Prashant V. Patil </span></b>
                <br>
                <b><span class="font-weight-900">Staff Coordinator 2:</span>&nbsp;&nbsp; <span class="font-weight-600"> Prof. Smita Mekallke </span></b> <br><br>
                <span class="font-weight-900">Student Volunteers 1:</span>&nbsp;&nbsp;<span class="font-weight-600"> Punitkumar S.H. &nbsp; [8867320949]</span>
                <br>
                <span class="font-weight-900">Student Volunteers 2:</span>&nbsp;&nbsp;<span class="font-weight-600"> Prasad M. Patil &nbsp;[8951453772]</span>
                <br>
                <span class="font-weight-900">Student Volunteers 3:</span>&nbsp;&nbsp;<span class="font-weight-600"> Shreya kolhapure &nbsp; [9980961835]</span>
                <br>
                <span class="font-weight-900">Student Volunteers 4:</span>&nbsp;&nbsp;<span class="font-weight-600"> Krishna Chavan &nbsp;[9886084332]</span>
                <br>
                <span class="font-weight-900">Student Volunteers 5:</span>&nbsp;&nbsp;<span class="font-weight-600"> Pranali Sulebhavi &nbsp; [8904122142]</span>
                <br>
                <span class="font-weight-900">Student Volunteers 6:</span>&nbsp;&nbsp;<span class="font-weight-600"> Pradnya Chapagoakar &nbsp;[8971291134]</span>
                <br>
                <span class="font-weight-900">Student Volunteers 7:</span>&nbsp;&nbsp;<span class="font-weight-600"> Prashant Takkekar &nbsp;[9481559425]</span>
                <br>
                <span class="font-weight-900">Student Volunteers 8:</span>&nbsp;&nbsp; <span class="font-weight-600"> Mallikarjun Kumbar &nbsp; [9611442333] </span> <br><br>
                <br>
                <h1> Details of event:</h1>  
                <span class="font-weight-900" style="color:red;">Audition Date: </span>&nbsp;<span class="font-weight-600"> 07-03-2019 (10.00 am) </span><br>
                <span class="font-weight-900" style="color:red;">Audition Location: </span>&nbsp;<span class="font-weight-600">Physics Lab </span><br>
                <span class="font-weight-900">Number of rounds:</span>&nbsp; <span class="font-weight-600"> 1 </span><br> 
                <span class="font-weight-900">Entry Fee:</span>&nbsp; <span class="font-weight-600">Rs.500/- </span><br>  
                <span class="font-weight-900">No. of participants / Team size (with conditions): </span>&nbsp;<span class="font-weight-600">5-10</span></b><br>
                <span class="font-weight-900">Timing and date of event: </span>&nbsp;<span class="font-weight-600">  </span><br>
                <span class="font-weight-900">Number of prizes: </span>&nbsp;<span class="font-weight-600">  </span><br>
                    <br>
                    <h5>Rules:</h5>
         
                    1. Groups must follow the theme. <br>
                    2. The time given to every group is 5 minutes. <br>
                    3. Final selection of participating group will be made based on an initial screening/audition. <br>
                    4. Auditions will be held on 07/03/2019 in Physics Lab at 10.00am. <br>
                    5. Participants must showcase their final outfits and choreography at the time of auditions. <br>
                    6. Team will be judged on costumes, walking style, stance and attitude. <br>
                    7. Vulgarity is strictly prohibited. <br>
                    
                               
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      </section>
              <br><br><br><br><br><br>
                   </section>         
              
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="section section-lg">
                </li>
              </ul>
            </div>
          </div>
        </div>
        </div>
      </div>
    </section>
                    </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- SVG separator -->
      <div class="separator separator-bottom separator-skew zindex-100">
        <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1" xmlns="http://www.w3.org/2000/svg">
          <polygon class="fill-white" points="2560 0 2560 100 0 100"></polygon>
        </svg>
      </div>
    </section>
    
        </div>
          </section>
    
    </section>
      </main>
   <footer class="footer has-cards">
        <div class="container"> 
      <!-- <div class="row row-grid align-items-center my-md">
        <div class="col-lg-6">
          <h3 class="text-primary font-weight-light mb-2">Thank you for supporting us!</h3>
          <h4 class="mb-0 font-weight-light">Let's get in touch on any of these platforms.</h4>
        </div>
        <div class="col-lg-6 text-lg-center btn-wrapper">
          <a target="_blank" href="https://twitter.com/creativetim" class="btn btn-neutral btn-icon-only btn-twitter btn-round btn-lg" data-toggle="tooltip" data-original-title="Follow us">
            <i class="fa fa-twitter"></i>
          </a>
          <a target="_blank" href="https://www.facebook.com/creativetim" class="btn btn-neutral btn-icon-only btn-facebook btn-round btn-lg" data-toggle="tooltip" data-original-title="Like us">
            <i class="fa fa-facebook-square"></i>
          </a>
          <a target="_blank" href="https://dribbble.com/creativetim" class="btn btn-neutral btn-icon-only btn-dribbble btn-lg btn-round" data-toggle="tooltip" data-original-title="Follow us">
            <i class="fa fa-dribbble"></i>
          </a>
          <a target="_blank" href="https://github.com/creativetimofficial" class="btn btn-neutral btn-icon-only btn-youtube btn-round btn-lg" data-toggle="t0ooltip" data-original-title="Star on Github">
            <i class="fa fa-youtube"></i>
          </a>
        </div> -->
      </div>
      <hr>
      <div class="row align-items-center justify-content-md-between">
        <div class="col-md-6">
          <div class="copyright">
            &copy; 2019
            <a href="https://www.creative-tim.com" target="_blank">JCE website committee</a>
          </div>
        </div>
        <div class="col-md-6">
           <ul class="nav nav-footer justify-content-end">
            <!-- <li class="nav-item">
              <a href="https://www.creative-tim.com" class="nav-link" target="_blank">Creative Tim</a>
            </li>  -->
            <li class="nav-item">
              <a href="https://www.creative-tim.com/presentation" class="nav-link" target="_blank">About Us</a>
            </li>
             <!-- <li class="nav-item">
              <a href="http://blog.creative-tim.com" class="nav-link" target="_blank">Blog</a>
            </li>
            <li class="nav-item">
              <a href="https://github.com/creativetimofficial/argon-design-system/blob/master/LICENSE.md" class="nav-link" target="_blank">MIT License</a>
            </li>
          </ul>  -->
        </div>
      </div>
    </div>
  </footer>
  <!-- Core -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/popper/popper.min.js"></script>
  <script src="vendor/bootstrap/bootstrap.min.js"></script>
  <script src="vendor/headroom/headroom.min.js"></script>
  <!-- Argon JS -->
  <script src="js/argon.js?v=1.0.1"></script>
</body>

</html>
