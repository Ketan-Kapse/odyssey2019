<?php
include("access.php");
?>
<html>
    <form action="logoutprocess.php" method="POST">
    <input type="Submit" value="LOGOUT">
    </form>
</html>